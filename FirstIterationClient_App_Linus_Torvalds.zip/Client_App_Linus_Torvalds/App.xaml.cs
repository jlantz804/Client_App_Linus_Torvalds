﻿using Microsoft.Extensions.DependencyInjection;

namespace Client_App;

public partial class App : Application
{
	public App()
	{
		InitializeComponent();
	}

	private readonly Func<ContentPage>[] Pages =
	{
	() => new SchoolLevelPage(),
	() => new TeacherSignInPage(),
	() => new DrillsPage()
	};

	private const int pageToShow = 2;

	protected override Window CreateWindow(IActivationState? activationState)
	{
		return new Window(Pages[pageToShow]());
	}
}