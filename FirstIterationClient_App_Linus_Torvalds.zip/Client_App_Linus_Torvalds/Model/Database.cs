using System.Collections.ObjectModel;
using System.Diagnostics;
namespace Client_App.Model;

public partial class Database : IDatabase
{
    private static string url = "https://lwdwhssbtxzhuqyshsnm.supabase.co";
    private static string key = "sb_publishable_Zow77An5puKxY0A_VQqYJw_DmzbVE7V";
    Supabase.Client client;
    public ObservableCollection<Drill> Drills { get; private set; } = new();
    public ObservableCollection<Activity> Activities { get; private set; } = new();

    public Database()
    {
        client = new Supabase.Client(url,key);
    }

    public async Task SelectAllDrills()
    {
        try
        {
            var activities = (await client.From<Activity>().Get()).Models;
            var drills = (await client.From<Drill>().Get()).Models;

            var names = activities.ToDictionary(a => a.Id, a => a.Name);

            Activities.Clear();
            foreach (var a in activities) {
                Activities.Add(a);
            }

            Drills.Clear();
            foreach (var drill in drills)
            {
                drill.ActivityName = names.GetValueOrDefault(drill.ActivityId ?? -1, "");
                Drills.Add(drill);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error fetching movies: {ex.Message}");
        }
    }

    public async Task<DrillError> InsertDrill(Drill drillToInsert)
    {
        try
        {
            var response = await client.From<Drill>().Insert(drillToInsert);
            if (response.Models.Any())
            {
                Drills.Add(response.Models.First());
            }
            else
            {
                return DrillError.DuplicateDrill;
            }
        }
        catch (Exception ex)
        {
            Debug.WriteLine("Insert failed, {0}", ex);
            return ex.Message.Contains("already exists") || ex.Message.Contains("duplicate key") ? DrillError.DuplicateDrill : DrillError.DBAdditionError;
        }
        return DrillError.NoError;
    }

    public Task<DrillError> UpdateDrill(Drill currentDrill, string drillName)
    {
        throw new NotImplementedException();
    }

    public Task<DrillError> DeleteDrill(Drill drillToDelete)
    {
        throw new NotImplementedException();
    }
}