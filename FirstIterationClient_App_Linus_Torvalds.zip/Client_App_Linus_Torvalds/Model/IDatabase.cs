using System.Collections.ObjectModel;

namespace Client_App.Model;

public interface IDatabase
{
    public ObservableCollection<Drill> Drills { get; }
    ObservableCollection<Activity> Activities { get; }
    public Task SelectAllDrills();
    public Task<DrillError> InsertDrill(Drill drillToInsert);
    public Task<DrillError> UpdateDrill(Drill currentDrill, String drillName);
    public Task<DrillError> DeleteDrill(Drill drillToDelete);
}