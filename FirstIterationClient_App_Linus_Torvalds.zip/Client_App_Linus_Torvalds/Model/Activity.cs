using System.ComponentModel;
using Supabase.Postgrest.Attributes;

namespace Client_App.Model;

[Table("activities")]
public class Activity : ObservableBaseModel
{
    [PrimaryKey("id")] public int Id { get; set; }
    [Column("name")]   public string Name { get; set; } = "";
}

