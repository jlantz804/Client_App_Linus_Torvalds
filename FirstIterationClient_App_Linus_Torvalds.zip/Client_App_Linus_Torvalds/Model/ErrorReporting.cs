namespace Client_App.Model;

public enum DrillError
{
    NoError,
    DuplicateDrill,
    DBAdditionError
}